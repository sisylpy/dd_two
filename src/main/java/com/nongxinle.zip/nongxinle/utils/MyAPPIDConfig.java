/**
 * com.nongxinle.utils class
 *
 * @Author: peiyi li
 * @Date: 2020-05-22 09:11
 */

package com.nongxinle.utils;

import com.github.wxpay.sdk.WXPayConfig;

import java.io.InputStream;

/**
 *@author lpy
 *@date 2020-05-22 09:11
 */


public class MyAPPIDConfig  {

    /**
     * 用户名： lipeiyi@grainservice.club
     * 密码： Lpy87176693
     * @return 李沛谊
     */
    public String getShixianZhizuoAppId(){ return "wx5da692125f70da73"; }
    public String getShixianZhizuoScreat(){
        return "c4ae83d718aec30c881e509cc647ef4e";
    }
    /**
     * 用户名： lipeiyi@grainservice.club
     * 密码： Lpy87176693
     * @return 李沛谊
     */
    public String getShixianGuanliAppId(){ return "wxd18ed10d341c957b"; }
    public String getShixianGuanliScreat(){
        return "e3c04bb058d205c6402cd073aba44212";
    }


    /**
     * 用户名： lipeiyi@grainservice.club
     * 密码： Lpy87176693
     * @return 李沛谊
     */
    public String getShixianLiliAppId(){ return "wx159c5a46d80e4500"; }
    public String getShixianLiliScreat(){
        return "319555884ced0820af582ae2e622ee6b";
    }


    /**
     * 用户名： liziyishangone@163.com
     * 密码： Lpy87176693
     * @return 张君
     */
    public String getLiansuocaigouguanliduanAppId(){ return "wx21c7f34ad4a32e6e"; }
    public String getLiansuocaigouguanliduanScreat(){
        return "157214d30f8d53f4207781d4f0113f5e";
    }

    /**
     * 用户名： liziyishangone@163.com
     * 密码： Lpy87176693
     * @return 张君
     */
    public String getLiancaiKufangAppId(){ return "wx3dd89272ccfe63a7"; }
    public String getLiancaiKufangScreat(){
        return "1f9543a012cab8874f88d0779d05251b";
    }


    /**
     * 用户名： liziyishangthree@163.com
     * 密码： Lpy87176693
     * @return 张君
     */
    public String getLiancaiCaigouAppId(){ return "wxa54d493fec778220"; }
    public String getLiancaiCaigouScreat(){
        return "8ed626fe9b01df101a134c821a9598e3";
    }


    /**
     * 用户名： liziyishangfour@163.com
     * 密码： Lpy87176693
     * @return 张君
     */
    public String getLiancaiCenterDepartmentAppId(){ return "wxb34209fc922dc9b8"; }
    public String getLiancaiCenterDepartmentScreat(){
        return "6ad1e06357aa42d36d111760d931a367";
    }


    /**
     * 用户名：  liziyishangfive@163.com
     * 密码： Lpy87176693
     * @return  张君
     */
    public String getLiancaiMendianAppId(){
        return "wx97f8fe9b8570e3a4";
    }
    public String getLiancaiMendianScreat(){
        return "685b78da3c22f6608566f423867ee94c";
    }


    /**
     * 用户名： lizidistribute@sina.com
     * 密码： Lpy87176693
     * @return 芳芳
     */
    public String getLiancaiAppoinSupplierAppId(){
        return "wxaad78fd4a9d898cf";
    }
    public String getLiancaiAppoinSupplierScreat(){
        return "190652f297cf9826ebb72c29aa1ff0f6";
    }




//    public String getYishangpifaAppId(){
//        return "wx97f8fe9b8570e3a4";
//    }
//    public String getYishangpifScreat(){
//        return "685b78da3c22f6608566f423867ee94c";
//    }




    /**
     * 用户名： liziwillorder@163.com
     * 密码： Lpy87176693
     * @return
     */
    public String getJinriDinghuoAppId(){
        return "wxfa34176649802291";
    }
    public String getJinriDinghuoScreat(){
        return "3a49926735fa7d59cfe0eb2f418a18e4";
    }



    /**
     * shanghuo zanyong printID
     * @return
     */
    public String getShanghuoAppID(){
        return "wxe7ab0f97ea2c6417";
    }
    public String getShanghuoScreat(){
        return "a6dc260736a93917dfba0baa32de470a";
    }

    /**
     * 用户名： lizicommunitypur@sina.com
     * 密码： Lpy87176693
     */
    public String getComPurchaseAppID() {
        return "wx83df2ca148aa617b";
    }
    public String getComPurchaseScreat(){
        return "fe54724ab5d2f260fe187f7dd5dd08cc";
    }

    /**
     *用户名： lizicommunityres@sina.com
     * @return
     */
    public String getComResAppID() {
        return "wxaf7057ece792633d";
    }
    public String getComResScreat(){
        return "9a6a115766a6123f326ee3cd31629b75";
    }




    /**
     * 用户名： lizipurchase@sina.com
     * 密码： Lpy87176693
     * @return AppId
     */
    //todo 注销
    public String getPurchaseAppID() {
        return "wx042578a6884b5c0d";
    }
    public String getPurchaseScreat(){
        return "22c00508b091ab6fed36aca8ca1faf59";
    }



    /**
     * 用户名： texiansongdh@sina.com
     * 密码： Lpy87176693
     * @return AppId
     */
    public String getOrderAppID() {
        return "wx1ea78d3f33234284";
    }

    public String getOrderScreat(){
        return "9b6bdf783dd366597a4c52484fe1b577";
    }


    /**
     * 用户名： Lizicaidi@sina.com
     * 密码： Lpy87176693
     * @return AppId
     */
    public String getTexiansongAppID() {
        return "wx87baf9dcf935518a";
    }

    public String getTexiansongScreat(){
        return "a7e380c56222dfbd5377aeea6bb1eba2";
    }

    public String getTexiansongCaigouAppId(){
        return "wx58ba279bc3d04c4a";
    }
    public String getTexiansongCaigouScreat(){
        return "07bcf1a46323e6c05fcf4404ddd0582f";
    }



    public String getLiziDriverAppID() {
        return "wx2dccb807db0ea0d7";
    }

    public String getLiziDriverScreat(){
        return "1433f8015b34fc6534c7948e216f2512";
    }


    /**
     * 用户名： lizirestraunt@sina.com
     * @return
     */
    public String getRestrauntAppID() {
        return "wx975628eb436db001";
    }

    public String getRestrauntScreat(){
        return "4a7364ca197d7b4315f4f9f41361ed0b";
    }

    public String getCommunityAppID() {
        return "wx703088926758c568";
    }

    public String getCommunityScreat(){
        return "7f23a36c0672e7f72a9ecffb3e8fb38d";
    }






}
