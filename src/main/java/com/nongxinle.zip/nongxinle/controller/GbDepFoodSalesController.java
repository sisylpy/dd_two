package com.nongxinle.controller;

/**
 * 
 *
 * @author lpy
 * @date 03-27 21:55
 */

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.nongxinle.entity.GbDepFoodSalesEntity;
import com.nongxinle.service.GbDepFoodSalesService;
import com.nongxinle.utils.PageUtils;
import com.nongxinle.utils.R;


@RestController
@RequestMapping("gbdepfoodsales")
public class GbDepFoodSalesController {
	@Autowired
	private GbDepFoodSalesService gbDepFoodSalesService;
	

	
}
