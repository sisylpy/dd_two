package com.nongxinle.entity;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class WeChatSuiteReturn {

    private Integer errcode;


    private String suite_access_token;


}
