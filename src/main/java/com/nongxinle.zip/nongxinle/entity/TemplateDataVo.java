/**
 * com.nongxinle.entity class
 *
 * @Author: peiyi li
 * @Date: 2020-03-11 12:10
 */

package com.nongxinle.entity;

/**
 *@author lpy
 *@date 2020-03-11 12:10
 */
import lombok.Data;

/*
 * 设置推送的文字和颜色
 * */
@Data
public class TemplateDataVo {

    private String character_string1;

    private String amount2;

    private String date3;

    private String phrase5;

    private String thing7;



}

