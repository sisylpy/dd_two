package com.nongxinle.dao;

/**
 * 
 *
 * @author lpy
 * @date 10-07 09:12
 */

import com.nongxinle.entity.NxDistributerAliasEntity;


public interface NxDistributerAliasDao extends BaseDao<NxDistributerAliasEntity> {
	
}
