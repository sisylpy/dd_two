package com.nongxinle.dao;

/**
 * 
 *
 * @author lpy
 * @date 02-18 14:22
 */

import com.nongxinle.entity.GbDepInventoryGoodsMonthTotalEntity;


public interface GbDepInventoryGoodsMonthTotalDao extends BaseDao<GbDepInventoryGoodsMonthTotalEntity> {
	
}
