package com.nongxinle.dao;

/**
 * 
 *
 * @author lpy
 * @date 08-19 12:35
 */

import com.nongxinle.entity.SysCityMarketEntity;


public interface SysCityMarketDao extends BaseDao<SysCityMarketEntity> {
	
}
