package com.nongxinle.dao;

/**
 * 
 *
 * @author lpy
 * @date 07-30 18:51
 */

import com.nongxinle.entity.NxAliasEntity;


public interface NxAliasDao extends BaseDao<NxAliasEntity> {
	
}
