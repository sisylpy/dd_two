package com.nongxinle.dao;

/**
 * 
 *
 * @author lpy
 * @date 04-27 12:56
 */

import com.nongxinle.entity.NxLabelEntity;


public interface NxLabelDao extends BaseDao<NxLabelEntity> {
	
}
