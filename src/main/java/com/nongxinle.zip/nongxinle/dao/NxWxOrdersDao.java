package com.nongxinle.dao;

/**
 * 
 *
 * @author lpy
 * @date 05-21 22:15
 */

import com.nongxinle.entity.NxWxOrdersEntity;


public interface NxWxOrdersDao extends BaseDao<NxWxOrdersEntity> {
	
}
