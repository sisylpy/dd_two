package com.nongxinle.dao;

/**
 * 
 *
 * @author lpy
 * @date 06-04 11:07
 */

import com.nongxinle.entity.GbDistributerModuleEntity;


public interface GbDistributerModuleDao extends BaseDao<GbDistributerModuleEntity> {
	
}
