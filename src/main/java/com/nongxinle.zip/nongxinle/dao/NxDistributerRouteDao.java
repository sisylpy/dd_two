package com.nongxinle.dao;

/**
 * 
 *
 * @author lpy
 * @date 06-14 20:17
 */

import com.nongxinle.entity.NxDistributerRouteEntity;


public interface NxDistributerRouteDao extends BaseDao<NxDistributerRouteEntity> {
	
}
