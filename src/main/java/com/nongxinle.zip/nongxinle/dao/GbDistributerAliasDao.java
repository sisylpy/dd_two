package com.nongxinle.dao;

/**
 * 
 *
 * @author lpy
 * @date 10-07 09:12
 */

import com.nongxinle.entity.GbDistributerAliasEntity;


public interface GbDistributerAliasDao extends BaseDao<GbDistributerAliasEntity> {

	
}
