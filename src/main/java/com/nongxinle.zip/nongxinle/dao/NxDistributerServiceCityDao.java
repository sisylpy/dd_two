package com.nongxinle.dao;

/**
 * 
 *
 * @author lpy
 * @date 08-19 13:03
 */

import com.nongxinle.entity.NxDistributerServiceCityEntity;


public interface NxDistributerServiceCityDao extends BaseDao<NxDistributerServiceCityEntity> {
	
}
