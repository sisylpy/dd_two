package com.nongxinle.dao;

/**
 * 用户与角色对应关系
 *
 * @author lpy
 * @date 06-20 10:55
 */

import com.nongxinle.entity.NxDistributerUserRoleEntity;


public interface NxDistributerUserRoleDao extends BaseDao<NxDistributerUserRoleEntity> {
	
}
