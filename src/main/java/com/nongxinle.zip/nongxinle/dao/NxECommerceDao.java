package com.nongxinle.dao;

/**
 * 
 *
 * @author lpy
 * @date 11-28 21:17
 */

import com.nongxinle.entity.NxECommerceEntity;


public interface NxECommerceDao extends BaseDao<NxECommerceEntity> {
	
}
