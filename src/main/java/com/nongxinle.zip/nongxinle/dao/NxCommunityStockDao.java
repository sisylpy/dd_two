package com.nongxinle.dao;

/**
 * 
 *
 * @author lpy
 * @date 06-08 09:22
 */

import com.nongxinle.entity.NxCommunityStockEntity;


public interface NxCommunityStockDao extends BaseDao<NxCommunityStockEntity> {
	
}
