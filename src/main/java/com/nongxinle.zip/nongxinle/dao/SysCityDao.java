package com.nongxinle.dao;

/**
 * 
 *
 * @author lpy
 * @date 08-19 12:35
 */

import com.nongxinle.entity.SysCityEntity;


public interface SysCityDao extends BaseDao<SysCityEntity> {
	
}
