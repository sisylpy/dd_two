package com.nongxinle.dao;

/**
 * 
 *
 * @author lpy
 * @date 02-18 14:22
 */

import com.nongxinle.entity.GbDepInventoryGoodsWeekTotalEntity;


public interface GbDepInventoryGoodsWeekTotalDao extends BaseDao<GbDepInventoryGoodsWeekTotalEntity> {
	
}
