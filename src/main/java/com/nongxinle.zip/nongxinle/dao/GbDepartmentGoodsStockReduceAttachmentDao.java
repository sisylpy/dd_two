package com.nongxinle.dao;

/**
 * 
 *
 * @author lpy
 * @date 05-29 16:35
 */

import com.nongxinle.entity.GbDepartmentGoodsStockReduceAttachmentEntity;


public interface GbDepartmentGoodsStockReduceAttachmentDao extends BaseDao<GbDepartmentGoodsStockReduceAttachmentEntity> {
	
}
